	</div><!-- END MAIN -->

	<footer id="footer" role="contentinfo" class='L-1-1 gutters-1'>
		<div class='inner'>
			<div class='newsletter L-1-1'>
				<p class='L-1-1 gutters-1'>
					Inscrivez-vous pour recevoir des informations sur nos prochains spectacles et événements!
					<!--<?php echo do_shortcode('[rps-include post=107]') ?> -->
				</p>
				<div class='L-1-1 gutters-1 S-space-after-2'>
					<?php echo do_shortcode('[mc4wp_form]') ?>
				</div>
			</div>
			<div class='facebook L-1-1'>
				Suivez La Distillerie CIE sur <a href='http://www.facebook.com/distilleriecie'>Facebook</a>
			<div class='copyright L-1-2 right-aligned float-right'>
				Design & development by
				<a href="http://www.no-plans.com" target="_blank">No Plans</a>
			</div>
		</div>

<script src="<?php bloginfo('template_url'); ?>/js/lightbox.js"></script>

	</footer>
<?php wp_footer(); ?>

</body>
</html>